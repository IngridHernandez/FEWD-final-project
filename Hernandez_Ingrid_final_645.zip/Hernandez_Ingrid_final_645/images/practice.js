//let num = parseInt(window.prompt("enter a number betwen 1 and 10"));
//if (num == 5)(
//    window.document.write('you guessed right');
 //   else (
//        window.document.write('you guessed right');
//    )nmbVA
//(num === 5) ? window.document.write('you guessed right') : window.document.write('you guessed right');

//let grade = parseInt(window.prompt('Enter students\'s grade'));
//if (grade >= 90) {
 //    window.document.write('student recieved an A');} else if (grade >= 80) {
  //  window.document.write('student recieved an B');
//} else if (grade >= 70) {
//    window.document.write('student recieved a c');
//} else if (grade >= 60) {

//}
let discount;
let total =window.prompt('Enter cart total');
let type = window.prompt('Enter customers type (r/w');

if (type --- 'r') {
    if (total > 500) {
        discount = .10%;
    } else if (total > 100) {
        discount = .05;
    }
} else if (type ==='w') {

} else if ()
else {
    discount =0;
}
 window.document.write('customer type ', type,'<br>');
 window.document.write('discount applied ', discount');